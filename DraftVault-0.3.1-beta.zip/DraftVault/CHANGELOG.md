# Changelog

## 0.3.1 beta

- Made the version timeline independently scrollable with a visible scrollbar.
- Automatically loads the next 50 older versions when scrolling near the bottom; no versions need to be deleted to reveal older history.
- Kept the manual “Load older versions” control as a fallback.


## 0.3.0 beta

- Added per-conversation protection (pinning) to exclude important histories from inactivity cleanup and storage-limit trimming.
- Added version comparison with inline added/removed text highlighting and a bounded diff algorithm for long drafts.
- Added JSON backup export and merge-based import, including protected conversation settings and validation limits.
- Added a storage monitor showing the estimated size of DraftVault's encoded local history.
- Added an optional maximum storage setting; oldest unpinned revisions are trimmed first while the newest version in each conversation is preserved.
- Extended the persisted index with protected conversation IDs without changing the v2 history-record format.
- Updated the README with backup privacy, storage-cap behavior, and usage instructions.

## 0.2.0 beta

- Removed the 25-version-per-conversation and 60-conversation limits.
- Replaced fixed 30-day snapshot expiry with a configurable per-conversation inactivity window.
- Added retention period syntax: `s`, `m`, `h`, `mo`, and `y` (default `1mo`).
- Added automatic cleanup timers so stale conversation histories are removed while the plugin remains enabled.
- Added compact delta storage for similar revisions, with a full checkpoint at least every 100 delta versions.
- Added automatic migration of existing 0.1.0 history into a dedicated DraftVault IndexedDB store, separated from the shared plugin DataStore namespace.
- Added paged timeline loading (50 versions at a time) to keep the UI responsive with long histories.

## 0.1.0 hotfix

- Fixed the DraftVault modal crash caused by an undeclared `TextInput` component. The search field now uses a standard controlled HTML input, avoiding an extra UI-component dependency.
- The original release limited history to 25 versions per conversation, 60 conversations, and 30 days.
