# DraftVault 0.3.1-beta

DraftVault 0.3.1 improves long-history browsing on top of the 0.3.0 features.

### Highlights
- **Scrollable version history:** the version list now has its own scrollbar and automatically loads 50 older versions as you approach the bottom. You do not need to delete newer versions; a manual load button remains available as a fallback.
- **Protect conversations:** pin important histories so inactivity cleanup and storage-limit trimming leave them alone.
- **Compare versions:** select another saved version and see added and removed text highlighted inline.
- **Backup and restore:** export a JSON backup (up to 50 MB) and merge it into DraftVault later. Existing entries are not overwritten; matching version IDs are skipped.
- **Storage monitor and optional cap:** view DraftVault's estimated encoded history size and optionally set a maximum in MB. Oldest unpinned revisions are removed first; the latest version in each conversation is kept.

### Storage and privacy notes
- The storage reading is an estimate of DraftVault's encoded records, not total Discord/IndexedDB usage.
- A storage cap is best-effort. Protected histories and the latest version in each conversation are preserved, so the estimate can remain above the cap when no eligible revisions remain.
- JSON backups contain readable draft text and channel IDs. Keep exported backups private.
- Imports are limited to 50 MB and 250,000 versions per file, and apply the current retention and storage settings.

### Retention behavior
A conversation's full history stays available while new versions continue to be saved. Its history is removed after the configured inactivity period unless protected. The default remains `1mo`.

### Compatibility and testing
One codebase intended for Vencord and Equicord. A complete source build and live test inside both clients have not been performed here. The diff generator, backup validation/merge logic, storage trimming, retention logic, and TSX transpilation were tested separately.
