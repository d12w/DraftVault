/*
 * DraftVault - Local draft history for Discord
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

import "./styles.css";

import * as DataStore from "@api/DataStore";
import { definePluginSettings } from "@api/Settings";
import { ChatBarButton, ChatBarButtonFactory } from "@api/ChatButtons";
import ErrorBoundary from "@components/ErrorBoundary";
import { Logger } from "@utils/Logger";
import { IconComponent } from "@utils/types";
import definePlugin, { OptionType } from "@utils/types";
import type { Channel, RenderModalProps } from "@vencord/discord-types";
import { findByPropsLazy } from "@webpack";
import {
    ChannelRouter,
    ChannelStore,
    DraftStore,
    DraftType,
    GuildStore,
    Modal,
    UserStore,
    closeModal,
    openModal,
    useEffect,
    useMemo,
    useState,
} from "@webpack/common";

const logger = new Logger("DraftVault");
const MODAL_KEY = "draft-vault-modal";
const LEGACY_STORAGE_PREFIX = "DraftVault:v1:";
const INDEX_STORAGE_PREFIX = "DraftVault:v2:index:";
const HISTORY_STORAGE_PREFIX = "DraftVault:v2:history:";
const AUTOSAVE_DELAY_MS = 550;
const DEFAULT_RETENTION_PERIOD = "1mo";
const MAX_DRAFT_LENGTH = 10_000;
const MAX_TIMER_DELAY = 2_147_000_000;
const VERSIONS_PER_PAGE = 50;
const FULL_SNAPSHOT_INTERVAL = 100;
const MAX_BACKUP_FILE_SIZE = 50 * 1024 * 1024;
const MAX_IMPORTED_SNAPSHOTS = 250_000;

type SnapshotSource = "Auto-save" | "Before sending" | "Before restore";

interface DraftSnapshot {
    id: string;
    channelId: string;
    content: string;
    savedAt: number;
    source: SnapshotSource;
}

interface SnapshotDelta {
    baseId: string;
    prefix: number;
    suffix: number;
    insert: string;
}

type StoredDraftSnapshot = Omit<DraftSnapshot, "content"> & (
    | { content: string; delta?: never }
    | { content?: never; delta: SnapshotDelta }
);

interface StoredVaultIndex {
    version: 2;
    channelIds: string[];
    protectedChannelIds?: string[];
}

type VaultData = Record<string, DraftSnapshot[]>;

interface DraftVaultBackup {
    format: "DraftVaultBackup";
    version: 1;
    exportedAt: number;
    channels: VaultData;
    protectedChannelIds: string[];
}

interface DiffSegment {
    type: "equal" | "added" | "removed";
    text: string;
}

interface PendingCapture {
    userId: string;
    channelId: string;
    content: string;
    timer: ReturnType<typeof setTimeout>;
}

const DraftManager = findByPropsLazy("clearDraft", "saveDraft") as {
    saveDraft?: (channelId: string, content: string, draftType: number) => void;
};

const vaultCache = new Map<string, VaultData>();
const storedVaultCache = new Map<string, Record<string, StoredDraftSnapshot[]>>();
const protectedChannelCache = new Map<string, Set<string>>();
const vaultLoading = new Map<string, Promise<VaultData>>();
const writeQueues = new Map<string, Promise<void>>();
const pendingCaptures = new Map<string, PendingCapture>();
const observedDrafts = new Map<string, string>();
const vaultListeners = new Set<() => void>();
const DraftVaultStore = DataStore.createStore("DraftVault", "DraftVaultHistory");
const SETTINGS_KEYS = ["retentionPeriod", "storageLimitMB"] as const;
const cleanupTimers = new Map<string, ReturnType<typeof setTimeout>>();
let pluginStarted = false;

const settings = definePluginSettings({
    retentionPeriod: {
        type: OptionType.STRING,
        description: "Remove a conversation's entire draft history after this much time without a new saved version. Examples: 1s, 10m, 2h, 1mo, 1y.",
        placeholder: "1mo",
        default: DEFAULT_RETENTION_PERIOD,
        isValid: value => parseRetentionPeriod(value) !== null || "Use a positive number followed by s, m, h, mo or y (for example 1mo).",
        onChange: value => applyRetentionPolicy(value),
    },
    storageLimitMB: {
        type: OptionType.STRING,
        description: "Optional maximum size for DraftVault history in MB. Leave empty for no limit. Old unpinned versions are removed first; the newest version in each conversation is kept.",
        placeholder: "Unlimited",
        default: "",
        isValid: value => value.trim() === "" || parseStorageLimitMB(value) !== null || "Enter a positive storage limit in MB, or leave this blank for unlimited storage.",
        onChange: value => applyStorageLimit(value),
    },
});

function legacyStorageKey(userId: string) {
    return `${LEGACY_STORAGE_PREFIX}${userId}`;
}

function indexStorageKey(userId: string) {
    return `${INDEX_STORAGE_PREFIX}${userId}`;
}

function historyStorageKey(userId: string, channelId: string) {
    return `${HISTORY_STORAGE_PREFIX}${userId}:${channelId}`;
}

function notifyVaultListeners() {
    for (const listener of vaultListeners) {
        try {
            listener();
        } catch (error) {
            logger.warn("A DraftVault UI listener failed", error);
        }
    }
}

function parseRetentionPeriod(value: string): number | null {
    const match = /^\s*(\d+)\s*(mo|s|m|h|y)\s*$/i.exec(value);
    if (!match) return null;

    const amount = Number(match[1]);
    if (!Number.isSafeInteger(amount) || amount < 1) return null;

    const unit = match[2].toLowerCase();
    const unitMs: Record<string, number> = {
        s: 1_000,
        m: 60_000,
        h: 60 * 60_000,
        mo: 30 * 24 * 60 * 60_000,
        y: 365 * 24 * 60 * 60_000,
    };
    const duration = amount * unitMs[unit];
    return Number.isSafeInteger(duration) && duration > 0 ? duration : null;
}

function getRetentionPeriod(value?: string) {
    return parseRetentionPeriod(value ?? settings.store.retentionPeriod ?? DEFAULT_RETENTION_PERIOD)
        ?? parseRetentionPeriod(DEFAULT_RETENTION_PERIOD)!;
}

function parseStorageLimitMB(value: string): number | null {
    const normalized = value.trim();
    if (!normalized) return null;
    if (!/^\d+(?:\.\d{1,2})?$/.test(normalized)) return null;
    const megabytes = Number(normalized);
    if (!Number.isFinite(megabytes) || megabytes <= 0) return null;
    const bytes = megabytes * 1024 * 1024;
    return Number.isSafeInteger(Math.round(bytes)) ? Math.round(bytes) : null;
}

function getStorageLimitBytes(value?: string) {
    return parseStorageLimitMB(value ?? settings.store.storageLimitMB ?? "");
}

function formatBytes(bytes: number) {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    if (bytes < 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
    return `${(bytes / (1024 * 1024 * 1024)).toFixed(2)} GB`;
}

function estimateStoredVaultBytes(
    data: VaultData,
    stored: Record<string, StoredDraftSnapshot[]>,
    protectedChannels: Set<string> = new Set<string>(),
) {
    const index: StoredVaultIndex = {
        version: 2,
        channelIds: Object.keys(data),
        protectedChannelIds: [...protectedChannels].filter(channelId => Boolean(data[channelId])),
    };
    const serialized = JSON.stringify({
        index,
        histories: Object.fromEntries(Object.entries(stored).filter(([channelId]) => Boolean(data[channelId]))),
    });
    return new Blob([serialized]).size;
}

function enforceStorageLimit(
    data: VaultData,
    stored: Record<string, StoredDraftSnapshot[]>,
    protectedChannels: Set<string>,
    limitBytes: number | null,
) {
    if (limitBytes === null) return [] as string[];

    const changedChannels = new Set<string>();
    let currentBytes = estimateStoredVaultBytes(data, stored, protectedChannels);
    if (currentBytes <= limitBytes) return [];

    // Preserve the latest revision in every conversation. Remove the oldest
    // unpinned revisions first, rebuilding only the affected conversation's
    // delta chain after the removals.
    const candidates = Object.entries(data).flatMap(([channelId, snapshots]) => {
        if (protectedChannels.has(channelId) || snapshots.length <= 1) return [];
        return snapshots.slice(1).map(snapshot => ({
            channelId,
            snapshotId: snapshot.id,
            savedAt: snapshot.savedAt,
            approximateBytes: new Blob([JSON.stringify(stored[channelId]?.find(item => item.id === snapshot.id) ?? snapshot)]).size,
        }));
    }).sort((a, b) => a.savedAt - b.savedAt);

    const removedByChannel = new Map<string, Set<string>>();
    let approximateBytes = currentBytes;
    for (const candidate of candidates) {
        if (approximateBytes <= limitBytes) break;
        const ids = removedByChannel.get(candidate.channelId) ?? new Set<string>();
        ids.add(candidate.snapshotId);
        removedByChannel.set(candidate.channelId, ids);
        approximateBytes -= candidate.approximateBytes;
    }

    for (const [channelId, removedIds] of removedByChannel) {
        const remaining = data[channelId].filter(snapshot => !removedIds.has(snapshot.id));
        if (!remaining.length) continue;
        data[channelId] = remaining;
        stored[channelId] = encodeChannel(remaining);
        changedChannels.add(channelId);
    }

    // Re-encoding can alter delta sizes. If that pushes the estimate slightly
    // over budget, run one additional trim pass using the new encoded records.
    currentBytes = estimateStoredVaultBytes(data, stored, protectedChannels);
    if (currentBytes > limitBytes) {
        const secondPass = Object.entries(data).flatMap(([channelId, snapshots]) => {
            if (protectedChannels.has(channelId) || snapshots.length <= 1) return [];
            return snapshots.slice(1).map(snapshot => ({
                channelId,
                snapshotId: snapshot.id,
                savedAt: snapshot.savedAt,
                approximateBytes: new Blob([JSON.stringify(stored[channelId]?.find(item => item.id === snapshot.id) ?? snapshot)]).size,
            }));
        }).sort((a, b) => a.savedAt - b.savedAt);

        const secondPassRemovals = new Map<string, Set<string>>();
        for (const candidate of secondPass) {
            if (currentBytes <= limitBytes) break;
            const ids = secondPassRemovals.get(candidate.channelId) ?? new Set<string>();
            ids.add(candidate.snapshotId);
            secondPassRemovals.set(candidate.channelId, ids);
            currentBytes -= candidate.approximateBytes;
        }
        for (const [channelId, removedIds] of secondPassRemovals) {
            const remaining = data[channelId].filter(snapshot => !removedIds.has(snapshot.id));
            if (remaining.length <= 0) continue;
            data[channelId] = remaining;
            stored[channelId] = encodeChannel(remaining);
            changedChannels.add(channelId);
        }
    }

    return [...changedChannels];
}

function createDelta(base: string, next: string, baseId: string): SnapshotDelta | null {
    let prefix = 0;
    const prefixLimit = Math.min(base.length, next.length);
    while (prefix < prefixLimit && base.charCodeAt(prefix) === next.charCodeAt(prefix)) prefix++;

    let suffix = 0;
    const suffixLimit = Math.min(base.length - prefix, next.length - prefix);
    while (suffix < suffixLimit
        && base.charCodeAt(base.length - suffix - 1) === next.charCodeAt(next.length - suffix - 1)) {
        suffix++;
    }

    const insert = next.slice(prefix, next.length - suffix);
    // Store a full snapshot when the delta would not save meaningful space.
    if (insert.length + 40 >= next.length) return null;

    return { baseId, prefix, suffix, insert };
}

function encodeChannel(snapshots: DraftSnapshot[]): StoredDraftSnapshot[] {
    const encoded = new Array<StoredDraftSnapshot>(snapshots.length);
    let previous: DraftSnapshot | undefined;
    let deltasSinceFull = 0;

    // The in-memory list is newest-first; encode oldest-first so each delta
    // can refer to the immediately older version. Periodic full snapshots
    // keep recovery chains short and make stored data more resilient.
    for (let index = snapshots.length - 1; index >= 0; index--) {
        const snapshot = snapshots[index];
        const delta = previous && deltasSinceFull < FULL_SNAPSHOT_INTERVAL
            ? createDelta(previous.content, snapshot.content, previous.id)
            : null;

        if (delta) {
            encoded[index] = {
                id: snapshot.id,
                channelId: snapshot.channelId,
                savedAt: snapshot.savedAt,
                source: snapshot.source,
                delta,
            };
            deltasSinceFull++;
        } else {
            encoded[index] = {
                id: snapshot.id,
                channelId: snapshot.channelId,
                savedAt: snapshot.savedAt,
                source: snapshot.source,
                content: snapshot.content,
            };
            deltasSinceFull = 0;
        }

        previous = snapshot;
    }

    return encoded;
}

function encodeSnapshot(
    snapshot: DraftSnapshot,
    previousSnapshot?: DraftSnapshot,
    previousStored?: StoredDraftSnapshot[],
): StoredDraftSnapshot {
    let deltasSinceFull = 0;
    while (previousStored
        && deltasSinceFull < previousStored.length
        && deltasSinceFull < FULL_SNAPSHOT_INTERVAL
        && typeof previousStored[deltasSinceFull].content !== "string") {
        deltasSinceFull++;
    }
    const delta = previousSnapshot && previousStored?.length && deltasSinceFull < FULL_SNAPSHOT_INTERVAL
        ? createDelta(previousSnapshot.content, snapshot.content, previousSnapshot.id)
        : null;

    const metadata = {
        id: snapshot.id,
        channelId: snapshot.channelId,
        savedAt: snapshot.savedAt,
        source: snapshot.source,
    };

    return delta ? { ...metadata, delta } : { ...metadata, content: snapshot.content };
}

function decodeChannel(stored: StoredDraftSnapshot[], channelId: string): DraftSnapshot[] {
    const decoded = new Map<string, string>();
    const snapshots: DraftSnapshot[] = [];

    for (let index = stored.length - 1; index >= 0; index--) {
        const item = stored[index];
        if (!item || typeof item.id !== "string" || !Number.isFinite(item.savedAt)) continue;

        let content: string | undefined;
        if (typeof item.content === "string") {
            content = item.content;
        } else if (item.delta) {
            const base = decoded.get(item.delta.baseId);
            const { prefix, suffix, insert } = item.delta;
            if (base !== undefined
                && Number.isInteger(prefix) && Number.isInteger(suffix)
                && prefix >= 0 && suffix >= 0
                && prefix + suffix <= base.length
                && typeof insert === "string") {
                content = base.slice(0, prefix) + insert + base.slice(base.length - suffix);
            }
        }

        if (content === undefined) continue;
        decoded.set(item.id, content);
        snapshots.push({
            id: item.id,
            channelId,
            content,
            savedAt: item.savedAt,
            source: item.source === "Before sending" || item.source === "Before restore" ? item.source : "Auto-save",
        });
    }

    return snapshots.sort((a, b) => b.savedAt - a.savedAt);
}

function normalizeLegacyVault(raw: Record<string, unknown>): VaultData {
    const data: VaultData = {};
    for (const [channelId, value] of Object.entries(raw)) {
        if (!Array.isArray(value)) continue;
        const snapshots = value.filter((snapshot: any) =>
            Boolean(snapshot)
            && typeof snapshot.id === "string"
            && typeof snapshot.content === "string"
            && Number.isFinite(snapshot.savedAt)
        ).map((snapshot: any): DraftSnapshot => ({
            id: snapshot.id,
            channelId,
            content: snapshot.content,
            savedAt: snapshot.savedAt,
            source: snapshot.source === "Before sending" || snapshot.source === "Before restore" ? snapshot.source : "Auto-save",
        })).sort((a, b) => b.savedAt - a.savedAt);

        if (snapshots.length) data[channelId] = snapshots;
    }
    return data;
}

function pruneVault(
    data: VaultData,
    now = Date.now(),
    retentionMs = getRetentionPeriod(),
    protectedChannels: Set<string> = new Set(),
) {
    const removedChannelIds: string[] = [];
    for (const [channelId, snapshots] of Object.entries(data)) {
        if (protectedChannels.has(channelId)) continue;
        const latestSavedAt = snapshots[0]?.savedAt ?? 0;
        // Keep every version for an active conversation. Remove the whole
        // history only after that conversation has been inactive for the
        // configured retention period.
        if (!snapshots.length || latestSavedAt + retentionMs <= now) {
            delete data[channelId];
            removedChannelIds.push(channelId);
        }
    }
    return removedChannelIds;
}

function removeStoredChannels(userId: string, channelIds: string[]) {
    const stored = storedVaultCache.get(userId);
    for (const channelId of channelIds) {
        if (stored) delete stored[channelId];
    }
}

function clearCleanupTimer(userId: string) {
    const timer = cleanupTimers.get(userId);
    if (timer) clearTimeout(timer);
    cleanupTimers.delete(userId);
}

function scheduleCleanup(userId: string, retentionMs = getRetentionPeriod()) {
    if (!pluginStarted) return;
    clearCleanupTimer(userId);

    const data = vaultCache.get(userId);
    if (!data) return;
    const protectedChannels = protectedChannelCache.get(userId) ?? new Set<string>();

    const nextExpiry = Object.values(data).reduce((earliest, snapshots) => {
        const latestSavedAt = snapshots[0]?.savedAt ?? 0;
        const channelId = snapshots[0]?.channelId;
        return latestSavedAt && channelId && !protectedChannels.has(channelId)
            ? Math.min(earliest, latestSavedAt + retentionMs)
            : earliest;
    }, Number.POSITIVE_INFINITY);

    if (!Number.isFinite(nextExpiry)) return;

    const delay = Math.min(Math.max(0, nextExpiry - Date.now()), MAX_TIMER_DELAY);
    const timer = setTimeout(() => {
        cleanupTimers.delete(userId);
        const currentData = vaultCache.get(userId);
        if (!currentData) return;

        const currentProtected = protectedChannelCache.get(userId) ?? new Set<string>();
        const removedChannels = pruneVault(currentData, Date.now(), getRetentionPeriod(), currentProtected);
        if (removedChannels.length) {
            removeStoredChannels(userId, removedChannels);
            for (const channelId of removedChannels) currentProtected.delete(channelId);
            persistVault(userId, [], removedChannels);
            notifyVaultListeners();
        }
        scheduleCleanup(userId);
    }, delay);

    cleanupTimers.set(userId, timer);
}

function applyRetentionPolicy(value: string) {
    const retentionMs = parseRetentionPeriod(value);
    if (retentionMs === null) return;

    for (const [userId, data] of vaultCache) {
        const protectedChannels = protectedChannelCache.get(userId) ?? new Set<string>();
        const removedChannels = pruneVault(data, Date.now(), retentionMs, protectedChannels);
        if (removedChannels.length) {
            removeStoredChannels(userId, removedChannels);
            for (const channelId of removedChannels) protectedChannels.delete(channelId);
            persistVault(userId, [], removedChannels);
            notifyVaultListeners();
        }
        scheduleCleanup(userId, retentionMs);
    }
}

function applyStorageLimit(value: string) {
    const limitBytes = value.trim() ? parseStorageLimitMB(value) : null;
    if (value.trim() && limitBytes === null) return;

    for (const [userId, data] of vaultCache) {
        const stored = storedVaultCache.get(userId);
        if (!stored) continue;
        const protectedChannels = protectedChannelCache.get(userId) ?? new Set<string>();
        const changedChannels = enforceStorageLimit(data, stored, protectedChannels, limitBytes);
        if (changedChannels.length) {
            persistVault(userId, changedChannels);
            notifyVaultListeners();
        }
    }
}

async function getVault(userId: string): Promise<VaultData> {
    const cached = vaultCache.get(userId);
    if (cached) {
        scheduleCleanup(userId);
        return cached;
    }

    const existingLoad = vaultLoading.get(userId);
    if (existingLoad) return existingLoad;

    const load = (async () => {
        let data: VaultData = {};
        let storedChannels: Record<string, StoredDraftSnapshot[]> = {};
        const protectedChannels = new Set<string>();
        let shouldMigrate = false;
        const missingChannelIds: string[] = [];

        try {
            const storedIndex = await DataStore.get<StoredVaultIndex>(indexStorageKey(userId), DraftVaultStore);
            if (storedIndex?.version === 2 && Array.isArray(storedIndex.channelIds)) {
                for (const channelId of storedIndex.protectedChannelIds ?? []) {
                    if (typeof channelId === "string") protectedChannels.add(channelId);
                }
                const channelIds = [...new Set(storedIndex.channelIds.filter(id => typeof id === "string"))];
                const historyKeys = channelIds.map(channelId => historyStorageKey(userId, channelId));
                const storedHistories = await DataStore.getMany<StoredDraftSnapshot[] | undefined>(historyKeys, DraftVaultStore);

                for (let index = 0; index < channelIds.length; index++) {
                    const channelId = channelIds[index];
                    const history = storedHistories[index];
                    if (!Array.isArray(history)) {
                        missingChannelIds.push(channelId);
                        continue;
                    }
                    const decoded = decodeChannel(history, channelId);
                    if (decoded.length) {
                        storedChannels[channelId] = history;
                        data[channelId] = decoded;
                    } else {
                        missingChannelIds.push(channelId);
                    }
                }
            } else {
                const legacy = await DataStore.get<unknown>(legacyStorageKey(userId));
                if (legacy && typeof legacy === "object" && !Array.isArray(legacy)) {
                    data = normalizeLegacyVault(legacy as Record<string, unknown>);
                    storedChannels = Object.fromEntries(Object.entries(data).map(([channelId, snapshots]) => [
                        channelId,
                        encodeChannel(snapshots),
                    ]));
                    shouldMigrate = true;
                }
            }
        } catch (error) {
            logger.error("Failed to load local draft history", error);
        }

        const removedChannels = pruneVault(data, Date.now(), getRetentionPeriod(), protectedChannels);
        for (const channelId of removedChannels) {
            delete storedChannels[channelId];
            protectedChannels.delete(channelId);
        }
        for (const channelId of protectedChannels) {
            if (!data[channelId]) protectedChannels.delete(channelId);
        }

        vaultCache.set(userId, data);
        storedVaultCache.set(userId, storedChannels);
        protectedChannelCache.set(userId, protectedChannels);
        vaultLoading.delete(userId);

        const storageTrimmedChannels = enforceStorageLimit(
            data,
            storedChannels,
            protectedChannels,
            getStorageLimitBytes(),
        );

        if (shouldMigrate) {
            persistVault(userId, Object.keys(data), [], true);
        } else if (removedChannels.length || missingChannelIds.length || storageTrimmedChannels.length) {
            persistVault(userId, storageTrimmedChannels, [...removedChannels, ...missingChannelIds]);
        } else if (protectedChannels.size) {
            // Re-write the index so the current persisted schema includes
            // protected conversation IDs after loading an older v2 index.
            persistVault(userId);
        }

        scheduleCleanup(userId);
        return data;
    })();

    vaultLoading.set(userId, load);
    return load;
}

function persistVault(
    userId: string,
    updatedChannelIds: string[] = [],
    deletedChannelIds: string[] = [],
    removeLegacy = false,
): Promise<void> {
    const data = vaultCache.get(userId);
    const stored = storedVaultCache.get(userId);
    if (!data || !stored) return Promise.resolve();

    const updates: [string, StoredDraftSnapshot[]][] = [...new Set(updatedChannelIds)]
        .filter(channelId => data[channelId] && stored[channelId])
        .map(channelId => [historyStorageKey(userId, channelId), stored[channelId]]);
    const deletions = [...new Set(deletedChannelIds)]
        .map(channelId => historyStorageKey(userId, channelId));
    const index: StoredVaultIndex = {
        version: 2,
        channelIds: Object.keys(data),
        protectedChannelIds: [...(protectedChannelCache.get(userId) ?? new Set<string>())].filter(channelId => Boolean(data[channelId])),
    };

    const previous = writeQueues.get(userId) ?? Promise.resolve();
    const next = previous
        .catch(() => undefined)
        .then(async () => {
            if (deletions.length) await DataStore.delMany(deletions, DraftVaultStore);
            await DataStore.setMany([...updates, [indexStorageKey(userId), index]], DraftVaultStore);
            if (removeLegacy) await DataStore.del(legacyStorageKey(userId));
        })
        .catch(error => logger.error("Failed to persist local draft history", error));

    writeQueues.set(userId, next);
    return next;
}

function makeSnapshotId() {
    try {
        return crypto.randomUUID();
    } catch {
        return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
    }
}

async function captureSnapshot(userId: string, channelId: string, content: string, source: DraftSnapshot["source"]) {
    if (!content || !content.trim() || content.length > MAX_DRAFT_LENGTH) return;

    const data = await getVault(userId);
    const existing = data[channelId] ?? [];
    const latest = existing[0];

    // Never create duplicate versions for the same text, even when Discord emits
    // several store updates around the same send/clear operation.
    if (latest?.content === content) return;

    const now = Date.now();
    const snapshot: DraftSnapshot = {
        id: makeSnapshotId(),
        channelId,
        content,
        savedAt: now,
        source,
    };
    existing.unshift(snapshot);
    data[channelId] = existing;

    const stored = storedVaultCache.get(userId) ?? {};
    const nextStoredSnapshot = encodeSnapshot(snapshot, existing[1], stored[channelId]);
    storedVaultCache.set(userId, stored);
    stored[channelId] = [nextStoredSnapshot, ...(stored[channelId] ?? [])];

    const protectedChannels = protectedChannelCache.get(userId) ?? new Set<string>();
    const removedChannels = pruneVault(data, now, getRetentionPeriod(), protectedChannels);
    removeStoredChannels(userId, removedChannels);
    for (const removedChannelId of removedChannels) protectedChannels.delete(removedChannelId);
    const changedByStorageLimit = enforceStorageLimit(
        data,
        stored,
        protectedChannels,
        getStorageLimitBytes(),
    );
    persistVault(userId, [channelId, ...changedByStorageLimit], removedChannels);
    scheduleCleanup(userId);
    notifyVaultListeners();
}

function getCurrentUserId() {
    return UserStore.getCurrentUser()?.id ?? null;
}

function scanCurrentDrafts() {
    const userId = getCurrentUserId();
    if (!userId) return;

    const state = DraftStore.getState();
    const userDrafts = state[userId] ?? {};

    for (const [channelId, channelDrafts] of Object.entries(userDrafts)) {
        const draft = channelDrafts?.[DraftType.ChannelMessage];
        const content = draft?.draft;
        if (typeof content !== "string" || !content.trim()) continue;

        const observationKey = `${userId}:${channelId}`;
        if (observedDrafts.get(observationKey) === content) continue;
        observedDrafts.set(observationKey, content);

        const pendingKey = observationKey;
        const previous = pendingCaptures.get(pendingKey);
        if (previous) clearTimeout(previous.timer);

        const timer = setTimeout(() => {
            pendingCaptures.delete(pendingKey);
            void captureSnapshot(userId, channelId, content, "Auto-save");
        }, AUTOSAVE_DELAY_MS);

        pendingCaptures.set(pendingKey, { userId, channelId, content, timer });
    }
}

function flushPendingCaptures() {
    for (const [key, pending] of pendingCaptures) {
        clearTimeout(pending.timer);
        pendingCaptures.delete(key);
        void captureSnapshot(pending.userId, pending.channelId, pending.content, "Auto-save");
    }
}

function getChannelDetails(channelId: string) {
    const channel = ChannelStore.getChannel(channelId) as Channel | undefined;

    if (!channel) {
        return { title: "Unavailable channel", subtitle: `Channel ID ${channelId}` };
    }

    if (channel.isPrivate?.()) {
        const recipients = (channel.recipients ?? []).map(id => {
            const user = UserStore.getUser(id);
            return user?.globalName || user?.username || id;
        }).filter(Boolean);

        return {
            title: channel.name || recipients.join(", ") || "Direct message",
            subtitle: channel.isGroupDM?.() ? "Group message" : "Direct message",
        };
    }

    const guild = channel.guild_id ? GuildStore.getGuild(channel.guild_id) : undefined;
    const parent = channel.parent_id ? ChannelStore.getChannel(channel.parent_id) : undefined;
    const title = channel.name ? `#${channel.name}` : "Unnamed channel";

    return {
        title,
        subtitle: [guild?.name, parent?.name].filter(Boolean).join(" · ") || "Server channel",
    };
}

function formatDate(timestamp: number) {
    return new Intl.DateTimeFormat(undefined, {
        month: "short",
        day: "numeric",
        hour: "numeric",
        minute: "2-digit",
    }).format(new Date(timestamp));
}

function relativeTime(timestamp: number) {
    const minutes = Math.max(0, Math.floor((Date.now() - timestamp) / 60_000));
    if (minutes < 1) return "Just now";
    if (minutes < 60) return `${minutes}m ago`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours}h ago`;
    const days = Math.floor(hours / 24);
    return `${days}d ago`;
}

function deleteSnapshot(userId: string, channelId: string, snapshotId: string) {
    const data = vaultCache.get(userId);
    if (!data?.[channelId]) return;

    data[channelId] = data[channelId].filter(snapshot => snapshot.id !== snapshotId);
    observedDrafts.delete(`${userId}:${channelId}`);
    if (!data[channelId].length) {
        delete data[channelId];
        removeStoredChannels(userId, [channelId]);
        protectedChannelCache.get(userId)?.delete(channelId);
        persistVault(userId, [], [channelId]);
    } else {
        const stored = storedVaultCache.get(userId) ?? {};
        stored[channelId] = encodeChannel(data[channelId]);
        storedVaultCache.set(userId, stored);
        persistVault(userId, [channelId]);
    }
    scheduleCleanup(userId);
    notifyVaultListeners();
}

function clearChannelHistory(userId: string, channelId: string) {
    const data = vaultCache.get(userId);
    if (!data || !data[channelId]) return;
    delete data[channelId];
    removeStoredChannels(userId, [channelId]);
    protectedChannelCache.get(userId)?.delete(channelId);
    observedDrafts.delete(`${userId}:${channelId}`);
    persistVault(userId, [], [channelId]);
    scheduleCleanup(userId);
    notifyVaultListeners();
}

function setChannelProtected(userId: string, channelId: string, isProtected: boolean) {
    const data = vaultCache.get(userId);
    if (!data?.[channelId]) return;

    const protectedChannels = protectedChannelCache.get(userId) ?? new Set<string>();
    if (isProtected) {
        protectedChannels.add(channelId);
    } else {
        protectedChannels.delete(channelId);
    }
    protectedChannelCache.set(userId, protectedChannels);

    const removedChannels = isProtected
        ? []
        : pruneVault(data, Date.now(), getRetentionPeriod(), protectedChannels);
    removeStoredChannels(userId, removedChannels);
    for (const removedChannelId of removedChannels) protectedChannels.delete(removedChannelId);

    const stored = storedVaultCache.get(userId);
    const changedByStorageLimit = stored
        ? enforceStorageLimit(data, stored, protectedChannels, getStorageLimitBytes())
        : [];
    persistVault(userId, changedByStorageLimit, removedChannels);
    scheduleCleanup(userId);
    notifyVaultListeners();
}

function downloadVaultBackup(userId: string) {
    const data = vaultCache.get(userId) ?? {};
    const backup: DraftVaultBackup = {
        format: "DraftVaultBackup",
        version: 1,
        exportedAt: Date.now(),
        channels: Object.fromEntries(Object.entries(data).map(([channelId, snapshots]) => [
            channelId,
            snapshots.map(snapshot => ({ ...snapshot })),
        ])),
        protectedChannelIds: [...(protectedChannelCache.get(userId) ?? new Set<string>())].filter(channelId => Boolean(data[channelId])),
    };
    const blob = new Blob([JSON.stringify(backup)], { type: "application/json" });
    if (blob.size > MAX_BACKUP_FILE_SIZE) {
        throw new Error(`This library is too large for a single backup file (${formatBytes(blob.size)}). The current export/import limit is ${formatBytes(MAX_BACKUP_FILE_SIZE)}.`);
    }
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `DraftVault-backup-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 30_000);
}

async function importVaultBackup(userId: string, file: File) {
    if (file.size <= 0 || file.size > MAX_BACKUP_FILE_SIZE) {
        throw new Error(`Choose a non-empty JSON backup smaller than ${formatBytes(MAX_BACKUP_FILE_SIZE)}.`);
    }

    let parsed: unknown;
    try {
        parsed = JSON.parse(await file.text());
    } catch {
        throw new Error("The selected file is not valid JSON.");
    }

    if (!parsed || typeof parsed !== "object") throw new Error("This file is not a DraftVault backup.");
    const backup = parsed as Partial<DraftVaultBackup>;
    if (backup.format !== "DraftVaultBackup" || backup.version !== 1 || !backup.channels || typeof backup.channels !== "object" || Array.isArray(backup.channels)) {
        throw new Error("This file is not a supported DraftVault backup (format version 1).");
    }

    const normalized: VaultData = {};
    let totalSnapshots = 0;
    for (const [channelId, rawSnapshots] of Object.entries(backup.channels)) {
        // Discord channel IDs are numeric snowflakes. Reject arbitrary object
        // keys rather than allowing imported JSON to populate prototype keys.
        if (!/^\d{5,25}$/.test(channelId) || !Array.isArray(rawSnapshots)) continue;
        const snapshots: DraftSnapshot[] = [];
        for (const rawSnapshot of rawSnapshots) {
            if (!rawSnapshot || typeof rawSnapshot !== "object") continue;
            const snapshot = rawSnapshot as Partial<DraftSnapshot>;
            if (typeof snapshot.id !== "string" || !snapshot.id || snapshot.id.length > 128
                || typeof snapshot.content !== "string" || snapshot.content.length > MAX_DRAFT_LENGTH
                || !Number.isFinite(snapshot.savedAt) || (snapshot.savedAt as number) <= 0) continue;

            snapshots.push({
                id: snapshot.id,
                channelId,
                content: snapshot.content,
                savedAt: snapshot.savedAt as number,
                source: snapshot.source === "Before sending" || snapshot.source === "Before restore" ? snapshot.source : "Auto-save",
            });
            totalSnapshots++;
            if (totalSnapshots > MAX_IMPORTED_SNAPSHOTS) {
                throw new Error(`The backup contains more than ${MAX_IMPORTED_SNAPSHOTS.toLocaleString()} versions. Split it into smaller backups before importing.`);
            }
        }
        if (snapshots.length) normalized[channelId] = snapshots.sort((a, b) => b.savedAt - a.savedAt);
    }

    if (!Object.keys(normalized).length) throw new Error("No valid draft versions were found in this backup.");

    const data = await getVault(userId);
    const stored = storedVaultCache.get(userId) ?? {};
    const protectedChannels = protectedChannelCache.get(userId) ?? new Set<string>();
    let importedCount = 0;
    let duplicateCount = 0;
    const updatedChannels = new Set<string>();

    for (const [channelId, importedSnapshots] of Object.entries(normalized)) {
        const current = data[channelId] ?? [];
        const ids = new Set(current.map(snapshot => snapshot.id));
        const merged = [...current];
        for (const snapshot of importedSnapshots) {
            if (ids.has(snapshot.id)) {
                duplicateCount++;
                continue;
            }
            ids.add(snapshot.id);
            merged.push(snapshot);
            importedCount++;
        }
        if (merged.length !== current.length) {
            data[channelId] = merged.sort((a, b) => b.savedAt - a.savedAt);
            stored[channelId] = encodeChannel(data[channelId]);
            updatedChannels.add(channelId);
        }
    }

    const importedProtected = Array.isArray(backup.protectedChannelIds)
        ? backup.protectedChannelIds.filter((channelId): channelId is string => typeof channelId === "string" && Boolean(data[channelId]))
        : [];
    for (const channelId of importedProtected) protectedChannels.add(channelId);
    protectedChannelCache.set(userId, protectedChannels);
    storedVaultCache.set(userId, stored);

    const beforeExpiryCount = Object.values(data).reduce((count, snapshots) => count + snapshots.length, 0);
    const expiredChannels = pruneVault(data, Date.now(), getRetentionPeriod(), protectedChannels);
    removeStoredChannels(userId, expiredChannels);
    for (const channelId of expiredChannels) {
        protectedChannels.delete(channelId);
        updatedChannels.delete(channelId);
        delete stored[channelId];
    }

    const afterExpiryCount = Object.values(data).reduce((count, snapshots) => count + snapshots.length, 0);

    const storageTrimmedChannels = enforceStorageLimit(data, stored, protectedChannels, getStorageLimitBytes());
    for (const channelId of storageTrimmedChannels) updatedChannels.add(channelId);
    const afterTrimCount = Object.values(data).reduce((count, snapshots) => count + snapshots.length, 0);
    const expiredCount = Math.max(0, beforeExpiryCount - afterExpiryCount);
    const trimmedCount = Math.max(0, afterExpiryCount - afterTrimCount);

    await persistVault(userId, [...updatedChannels], expiredChannels);
    scheduleCleanup(userId);
    notifyVaultListeners();
    return { importedCount, duplicateCount, trimmedCount, expiredCount };
}

function appendDiffSegment(segments: DiffSegment[], type: DiffSegment["type"], text: string) {
    if (!text) return;
    const previous = segments[segments.length - 1];
    if (previous?.type === type) previous.text += text;
    else segments.push({ type, text });
}

function buildTextDiff(oldText: string, newText: string): DiffSegment[] {
    const oldTokens = oldText.match(/\s+|[^\s]+/g) ?? [];
    const newTokens = newText.match(/\s+|[^\s]+/g) ?? [];
    const product = oldTokens.length * newTokens.length;

    if (product > 350_000) {
        let prefix = 0;
        while (prefix < oldText.length && prefix < newText.length && oldText[prefix] === newText[prefix]) prefix++;
        let suffix = 0;
        while (suffix < oldText.length - prefix && suffix < newText.length - prefix
            && oldText[oldText.length - suffix - 1] === newText[newText.length - suffix - 1]) suffix++;
        const segments: DiffSegment[] = [];
        appendDiffSegment(segments, "equal", oldText.slice(0, prefix));
        appendDiffSegment(segments, "removed", oldText.slice(prefix, oldText.length - suffix));
        appendDiffSegment(segments, "added", newText.slice(prefix, newText.length - suffix));
        appendDiffSegment(segments, "equal", suffix ? oldText.slice(oldText.length - suffix) : "");
        return segments;
    }

    const width = newTokens.length + 1;
    const table = new Uint32Array((oldTokens.length + 1) * width);
    for (let i = oldTokens.length - 1; i >= 0; i--) {
        for (let j = newTokens.length - 1; j >= 0; j--) {
            const cell = i * width + j;
            table[cell] = oldTokens[i] === newTokens[j]
                ? table[(i + 1) * width + j + 1] + 1
                : Math.max(table[(i + 1) * width + j], table[i * width + j + 1]);
        }
    }

    const reversed: DiffSegment[] = [];
    let i = 0;
    let j = 0;
    while (i < oldTokens.length && j < newTokens.length) {
        if (oldTokens[i] === newTokens[j]) {
            appendDiffSegment(reversed, "equal", oldTokens[i]);
            i++;
            j++;
        } else if (table[(i + 1) * width + j] >= table[i * width + j + 1]) {
            appendDiffSegment(reversed, "removed", oldTokens[i]);
            i++;
        } else {
            appendDiffSegment(reversed, "added", newTokens[j]);
            j++;
        }
    }
    while (i < oldTokens.length) appendDiffSegment(reversed, "removed", oldTokens[i++]);
    while (j < newTokens.length) appendDiffSegment(reversed, "added", newTokens[j++]);
    return reversed;
}

function restoreSnapshot(snapshot: DraftSnapshot) {
    const userId = getCurrentUserId();
    if (!userId) throw new Error("Discord user is not ready yet.");

    const channel = ChannelStore.getChannel(snapshot.channelId);
    if (!channel) throw new Error("This channel is not available in the current session.");

    const currentDraft = DraftStore.getDraft(snapshot.channelId, DraftType.ChannelMessage);
    if (currentDraft && currentDraft !== snapshot.content) {
        void captureSnapshot(userId, snapshot.channelId, currentDraft, "Before restore");
    }

    if (typeof DraftManager.saveDraft !== "function") {
        throw new Error("Discord's draft manager is not available. Try restarting Discord.");
    }

    // Use Discord's own draft manager; do not write directly to the editor DOM.
    DraftManager.saveDraft(snapshot.channelId, snapshot.content, DraftType.ChannelMessage);
    ChannelRouter.transitionToChannel(snapshot.channelId);
}

const VaultIcon: IconComponent = ({ width = 20, height = 20, className }) => (
    <svg width={width} height={height} viewBox="0 0 24 24" fill="none" className={className} aria-hidden="true">
        <path d="M4 7.5A2.5 2.5 0 0 1 6.5 5h11A2.5 2.5 0 0 1 20 7.5v10a2.5 2.5 0 0 1-2.5 2.5h-11A2.5 2.5 0 0 1 4 17.5v-10Z" stroke="currentColor" strokeWidth="1.7" />
        <path d="M4 9h16M8 5V3.8h8V5M9 13h6M9 16h4" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" />
    </svg>
);

function DraftVaultModal(props: RenderModalProps) {
    const [query, setQuery] = useState("");
    const [selectedChannelId, setSelectedChannelId] = useState<string | null>(null);
    const [selectedSnapshotId, setSelectedSnapshotId] = useState<string | null>(null);
    const [compareSnapshotId, setCompareSnapshotId] = useState<string | null>(null);
    const [vaultReady, setVaultReady] = useState(false);
    const [revision, setRevision] = useState(0);
    const [clearConfirmation, setClearConfirmation] = useState(false);
    const [restoreError, setRestoreError] = useState("");
    const [backupMessage, setBackupMessage] = useState("");
    const [backupError, setBackupError] = useState("");
    const [visibleVersionLimit, setVisibleVersionLimit] = useState(VERSIONS_PER_PAGE);
    const { retentionPeriod, storageLimitMB } = settings.use(SETTINGS_KEYS);

    useEffect(() => {
        let mounted = true;
        const listener = () => {
            if (mounted) setRevision(value => value + 1);
        };
        vaultListeners.add(listener);
        const userId = getCurrentUserId();
        if (userId) {
            void getVault(userId).then(() => {
                if (!mounted) return;
                setVaultReady(true);
                notifyVaultListeners();
            });
        } else {
            setVaultReady(true);
        }
        return () => {
            mounted = false;
            vaultListeners.delete(listener);
        };
    }, []);

    const userId = getCurrentUserId();
    const data = userId ? vaultCache.get(userId) ?? {} : {};
    const channelEntries = Object.entries(data)
        .map(([channelId, snapshots]) => ({
            channelId,
            snapshots,
            latest: snapshots[0]?.savedAt ?? 0,
            details: getChannelDetails(channelId),
        }))
        .sort((a, b) => b.latest - a.latest);

    const normalizedQuery = query.trim().toLocaleLowerCase();
    const visibleChannels = normalizedQuery
        ? channelEntries.filter(entry =>
            entry.details.title.toLocaleLowerCase().includes(normalizedQuery)
            || entry.details.subtitle.toLocaleLowerCase().includes(normalizedQuery)
            || entry.snapshots.some(snapshot => snapshot.content.toLocaleLowerCase().includes(normalizedQuery))
        )
        : channelEntries;

    const activeChannel = visibleChannels.find(entry => entry.channelId === selectedChannelId) ?? visibleChannels[0];
    const snapshots = activeChannel?.snapshots ?? [];
    const activeSnapshot = snapshots.find(snapshot => snapshot.id === selectedSnapshotId) ?? snapshots[0];
    const comparisonSnapshot = snapshots.find(snapshot => snapshot.id === compareSnapshotId && snapshot.id !== activeSnapshot?.id);
    const comparisonDiff = comparisonSnapshot && activeSnapshot
        ? buildTextDiff(comparisonSnapshot.content, activeSnapshot.content)
        : [];
    const snapshotCount = channelEntries.reduce((count, entry) => count + entry.snapshots.length, 0);
    const protectedChannels = userId ? protectedChannelCache.get(userId) ?? new Set<string>() : new Set<string>();
    const storageBytes = useMemo(() => userId
        ? estimateStoredVaultBytes(data, storedVaultCache.get(userId) ?? {}, protectedChannels)
        : 0, [userId, revision]);
    const storageLimitBytes = getStorageLimitBytes(storageLimitMB);
    const storagePercent = storageLimitBytes ? Math.min(100, storageBytes / storageLimitBytes * 100) : 0;
    const activeChannelProtected = Boolean(activeChannel && protectedChannels.has(activeChannel.channelId));

    function handleRestore() {
        if (!activeSnapshot) return;
        setRestoreError("");
        try {
            restoreSnapshot(activeSnapshot);
            props.onClose();
        } catch (error) {
            setRestoreError(error instanceof Error ? error.message : String(error));
        }
    }

    function handleExport() {
        if (!userId || !vaultReady) return;
        setBackupMessage("");
        setBackupError("");
        try {
            downloadVaultBackup(userId);
            setBackupMessage("Backup export started. Keep the JSON file somewhere safe; it contains your draft text.");
        } catch (error) {
            setBackupError(error instanceof Error ? error.message : String(error));
        }
    }

    async function handleImport(event: React.ChangeEvent<HTMLInputElement>) {
        const file = event.currentTarget.files?.[0];
        event.currentTarget.value = "";
        if (!file || !userId || !vaultReady) return;
        setBackupMessage("");
        setBackupError("");
        if (!window.confirm(`Import ${file.name} into this DraftVault? Existing versions will be kept and matching version IDs will be skipped. The backup contains private draft text.`)) return;
        try {
            const result = await importVaultBackup(userId, file);
            setBackupMessage(`Imported ${result.importedCount.toLocaleString()} versions; skipped ${result.duplicateCount.toLocaleString()} duplicates, expired ${result.expiredCount.toLocaleString()} versions under your retention policy, and trimmed ${result.trimmedCount.toLocaleString()} older versions for the storage limit.`);
        } catch (error) {
            setBackupError(error instanceof Error ? error.message : String(error));
        }
    }

    return (
        <Modal {...props} size="xl" title="DraftVault">
            <div className="dv-shell" data-revision={revision}>
                <header className="dv-hero">
                    <div className="dv-hero-copy">
                        <div className="dv-eyebrow"><span className="dv-status-dot" /> LOCAL DRAFT HISTORY</div>
                        <h2>Your words, never lost.</h2>
                        <p>Every important draft gets a second chance. Browse earlier versions and restore them whenever you need.</p>
                    </div>
                    <div className="dv-hero-actions">
                        <button type="button" className="dv-button dv-button-hero" onClick={handleExport} disabled={!userId || !vaultReady}>Export backup</button>
                        <label className="dv-button dv-button-hero dv-import-label">
                            Import backup
                            <input type="file" accept=".json,application/json" onChange={handleImport} disabled={!userId || !vaultReady} />
                        </label>
                    </div>
                    <div className="dv-hero-mark"><VaultIcon width={34} height={34}/></div>
                </header>

                <section className="dv-stats" aria-label="DraftVault statistics">
                    <div className="dv-stat-card">
                        <span className="dv-stat-label">Saved versions</span>
                        <strong>{snapshotCount}</strong>
                        <span className="dv-stat-foot">Across your conversations</span>
                    </div>
                    <div className="dv-stat-card">
                        <span className="dv-stat-label">Tracked channels</span>
                        <strong>{channelEntries.length}</strong>
                        <span className="dv-stat-foot">DMs, groups and servers</span>
                    </div>
                    <div className="dv-stat-card dv-stat-card-accent">
                        <span className="dv-stat-label">DraftVault storage</span>
                        <strong>{formatBytes(storageBytes)}</strong>
                        <span className="dv-stat-foot">{storageLimitMB.trim() ? `Optional limit: ${storageLimitMB} MB` : "No custom storage limit"}</span>
                        {storageLimitBytes !== null && <div className="dv-storage-track"><span style={{ width: `${storagePercent}%` }}/></div>}
                    </div>
                </section>

                <div className="dv-data-tools">
                    <span>Retention: <strong>{retentionPeriod}</strong> · Protected conversations: <strong>{protectedChannels.size}</strong></span>
                    <span>Storage size is an estimate of DraftVault's encoded local history.</span>
                </div>
                {(backupMessage || backupError || (storageLimitBytes !== null && storageBytes > storageLimitBytes)) && (
                    <div className={backupError || (storageLimitBytes !== null && storageBytes > storageLimitBytes) ? "dv-error" : "dv-notice"} role="status">
                        {backupError || (storageLimitBytes !== null && storageBytes > storageLimitBytes
                            ? "The storage limit cannot be met without deleting the newest version of a conversation or modifying protected conversations. Increase the limit or unprotect conversations."
                            : backupMessage)}
                    </div>
                )}

                <div className="dv-workspace">
                    <aside className="dv-sidebar">
                        <div className="dv-sidebar-heading">
                            <span>YOUR DRAFTS</span>
                            <span className="dv-count-pill">{channelEntries.length}</span>
                        </div>
                        <div className="dv-search-wrap">
                            <svg viewBox="0 0 24 24" width="16" height="16" fill="none" aria-hidden="true"><circle cx="10.8" cy="10.8" r="6.8" stroke="currentColor" strokeWidth="1.7"/><path d="m16 16 4.2 4.2" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round"/></svg>
                            <input
                                type="search"
                                className="dv-search-input"
                                value={query}
                                onChange={event => setQuery(event.currentTarget.value)}
                                placeholder="Search drafts..."
                                aria-label="Search draft history"
                            />
                        </div>
                        <div className="dv-channel-list">
                            {visibleChannels.map(entry => {
                                const active = activeChannel?.channelId === entry.channelId;
                                return (
                                    <button
                                        type="button"
                                        key={entry.channelId}
                                        className={`dv-channel-item${active ? " is-active" : ""}`}
                                        onClick={() => {
                                            setSelectedChannelId(entry.channelId);
                                            setSelectedSnapshotId(entry.snapshots[0]?.id ?? null);
                                            setCompareSnapshotId(null);
                                            setVisibleVersionLimit(VERSIONS_PER_PAGE);
                                            setClearConfirmation(false);
                                            setRestoreError("");
                                        }}
                                    >
                                        <span className="dv-channel-icon"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" aria-hidden="true"><path d="M5 5.5A2.5 2.5 0 0 1 7.5 3h9A2.5 2.5 0 0 1 19 5.5v9a2.5 2.5 0 0 1-2.5 2.5H11l-4.5 4v-4.2A2.5 2.5 0 0 1 5 14.5v-9Z" stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round"/></svg></span>
                                        <span className="dv-channel-meta">
                                            <strong>{entry.details.title}</strong>
                                            <small>{entry.details.subtitle}</small>
                                        </span>
                                        {protectedChannels.has(entry.channelId) && <span className="dv-protected-mark" title="Protected from automatic cleanup">PIN</span>}
                                        <span className="dv-channel-count">{entry.snapshots.length}</span>
                                    </button>
                                );
                            })}
                            {visibleChannels.length === 0 && (
                                <div className="dv-sidebar-empty">{channelEntries.length ? "No drafts match your search." : "Your saved drafts will appear here."}</div>
                            )}
                        </div>
                    </aside>

                    <main className="dv-main">
                        {activeChannel && activeSnapshot ? (
                            <>
                                <div className="dv-main-heading">
                                    <div>
                                        <span className="dv-section-kicker">CONVERSATION</span>
                                        <h3>{activeChannel.details.title}</h3>
                                        <p>{activeChannel.details.subtitle}</p>
                                    </div>
                                    <div className="dv-main-actions">
                                        <button
                                            type="button"
                                            className={`dv-button${activeChannelProtected ? " dv-button-pinned" : " dv-button-quiet"}`}
                                            onClick={() => { if (userId) setChannelProtected(userId, activeChannel.channelId, !activeChannelProtected); }}
                                            title={activeChannelProtected ? "Keep this conversation out of automatic cleanup and storage-limit trimming" : "Protect this conversation from automatic cleanup and storage-limit trimming"}
                                        >
                                            {activeChannelProtected ? "Protected" : "Protect"}
                                        </button>
                                        {clearConfirmation ? (
                                            <>
                                                <button type="button" className="dv-button dv-button-danger" onClick={() => { if (userId) clearChannelHistory(userId, activeChannel.channelId); setClearConfirmation(false); }}>Confirm clear</button>
                                                <button type="button" className="dv-button dv-button-quiet" onClick={() => setClearConfirmation(false)}>Cancel</button>
                                            </>
                                        ) : (
                                            <button type="button" className="dv-button dv-button-quiet" onClick={() => setClearConfirmation(true)}>Clear history</button>
                                        )}
                                    </div>
                                </div>

                                <div className="dv-history-layout">
                                    <section className="dv-timeline-section">
                                        <div className="dv-section-heading"><span>VERSION HISTORY</span><span>{snapshots.length} versions</span></div>
                                        <div
                                            className="dv-timeline-scroll"
                                            onScroll={event => {
                                                const element = event.currentTarget;
                                                const reachedBottom = element.scrollTop + element.clientHeight >= element.scrollHeight - 72;
                                                if (reachedBottom && visibleVersionLimit < snapshots.length) {
                                                    setVisibleVersionLimit(limit => Math.min(snapshots.length, limit + VERSIONS_PER_PAGE));
                                                }
                                            }}
                                        >
                                            <div className="dv-timeline">
                                            {snapshots.slice(0, visibleVersionLimit).map((snapshot, index) => (
                                                <div
                                                    key={snapshot.id}
                                                    className={`dv-version-item${activeSnapshot.id === snapshot.id ? " is-selected" : ""}`}
                                                    role="button"
                                                    tabIndex={0}
                                                    onClick={() => { setSelectedSnapshotId(snapshot.id); setCompareSnapshotId(current => current === snapshot.id ? null : current); setRestoreError(""); }}
                                                    onKeyDown={event => {
                                                        if (event.key === "Enter" || event.key === " ") {
                                                            event.preventDefault();
                                                            setSelectedSnapshotId(snapshot.id);
                                                            setCompareSnapshotId(current => current === snapshot.id ? null : current);
                                                            setRestoreError("");
                                                        }
                                                    }}
                                                >
                                                    <span className={`dv-timeline-marker${index === 0 ? " is-latest" : ""}`} />
                                                    <span className="dv-version-copy">
                                                        <strong>{index === 0 ? "Latest saved version" : `Version ${snapshots.length - index}`}</strong>
                                                        <small>{formatDate(snapshot.savedAt)} · {relativeTime(snapshot.savedAt)}</small>
                                                        <em>{snapshot.source}</em>
                                                    </span>
                                                    <button type="button" className="dv-version-delete" aria-label="Delete this version" onClick={event => { event.stopPropagation(); if (userId) deleteSnapshot(userId, activeChannel.channelId, snapshot.id); }}>
                                                        <svg viewBox="0 0 24 24" width="15" height="15" fill="none" aria-hidden="true"><path d="M4 7h16M9 7V4h6v3m3 0-.8 13H6.8L6 7m4 4v5m4-5v5" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/></svg>
                                                    </button>
                                                </div>
                                            ))}
                                            {snapshots.length > visibleVersionLimit && (
                                                <button
                                                    type="button"
                                                    className="dv-button dv-button-quiet"
                                                    onClick={() => setVisibleVersionLimit(limit => Math.min(snapshots.length, limit + VERSIONS_PER_PAGE))}
                                                >
                                                    Load {Math.min(VERSIONS_PER_PAGE, snapshots.length - visibleVersionLimit)} older versions
                                                </button>
                                            )}
                                            </div>
                                        </div>
                                    </section>

                                    <section className="dv-preview-section">
                                        <div className="dv-preview-topline">
                                            <span className="dv-section-kicker">SNAPSHOT PREVIEW</span>
                                            <span className="dv-source-badge">{activeSnapshot.source}</span>
                                        </div>
                                        <div className="dv-preview-date">{formatDate(activeSnapshot.savedAt)}</div>
                                        <div className="dv-compare-control">
                                            <label htmlFor="dv-compare-select">Compare with</label>
                                            <select
                                                id="dv-compare-select"
                                                value={comparisonSnapshot?.id ?? ""}
                                                onChange={event => setCompareSnapshotId(event.currentTarget.value || null)}
                                            >
                                                <option value="">No comparison</option>
                                                {snapshots.filter(snapshot => snapshot.id !== activeSnapshot.id).map(snapshot => (
                                                    <option key={snapshot.id} value={snapshot.id}>{formatDate(snapshot.savedAt)} · {relativeTime(snapshot.savedAt)}</option>
                                                ))}
                                            </select>
                                        </div>
                                        {comparisonSnapshot ? (
                                            <>
                                                <div className="dv-diff-legend"><span className="dv-diff-added-key">Added in selected version</span><span className="dv-diff-removed-key">Removed from comparison version</span></div>
                                                <pre className="dv-preview-content dv-diff-content">{comparisonDiff.map((segment, index) => (
                                                    <span key={`${segment.type}-${index}`} className={`dv-diff-${segment.type}`}>{segment.text}</span>
                                                ))}</pre>
                                            </>
                                        ) : (
                                            <pre className="dv-preview-content">{activeSnapshot.content}</pre>
                                        )}
                                        {restoreError && <div className="dv-error" role="alert">{restoreError}</div>}
                                        <button type="button" className="dv-button dv-button-primary dv-restore-button" onClick={handleRestore}>
                                            <svg viewBox="0 0 24 24" width="17" height="17" fill="none" aria-hidden="true"><path d="M4 12a8 8 0 1 0 2.34-5.66L4 8.7M4 4v4.7h4.7M12 7v5l3 2" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"/></svg>
                                            Restore this draft
                                        </button>
                                        <p className="dv-restore-note">Restores into Discord's composer. Nothing is sent automatically.</p>
                                    </section>
                                </div>
                            </>
                        ) : (
                            <div className="dv-empty-state">
                                <div className="dv-empty-icon"><VaultIcon width={34} height={34}/></div>
                                <h3>{channelEntries.length ? "No matching drafts" : "Nothing lost. Nothing to recover."}</h3>
                                <p>{channelEntries.length ? "Try another search term." : "DraftVault quietly saves versions as you write. Your next draft will show up here."}</p>
                            </div>
                        )}
                    </main>
                </div>

                <footer className="dv-footer">
                    <span><span className="dv-footer-dot"/> Private by design · Stored on this device only</span>
                    <span>Unprotected history expires after {retentionPeriod} of inactivity · Protected history is kept</span>
                </footer>
            </div>
        </Modal>
    );
}

function openDraftVault() {
    const userId = getCurrentUserId();
    if (userId) void getVault(userId).then(notifyVaultListeners);
    openModal(props => <ErrorBoundary><DraftVaultModal {...props} /></ErrorBoundary>, { modalKey: MODAL_KEY });
}

const DraftVaultChatButton = ErrorBoundary.wrap<Parameters<ChatBarButtonFactory>[0]>(({ isAnyChat }) => {
    if (!isAnyChat) return null;
    return (
        <ChatBarButton tooltip="Open DraftVault" onClick={openDraftVault}>
            <VaultIcon />
        </ChatBarButton>
    );
}, { noop: true });

function onDraftStoreChanged() {
    scanCurrentDrafts();
}

export default definePlugin({
    name: "DraftVault",
    description: "Keeps unlimited local draft revisions with compact storage, inactivity cleanup, protected histories, comparisons and JSON backups.",
    authors: [],
    tags: ["Chat", "Utility"],
    dependencies: ["ChatInputButtonAPI"],
    settings,

    chatBarButton: {
        icon: VaultIcon,
        render: props => <DraftVaultChatButton {...props} />,
    },

    toolboxActions: {
        "Open DraftVault": openDraftVault,
    },

    start() {
        pluginStarted = true;
        DraftStore.addChangeListener(onDraftStoreChanged);
        const userId = getCurrentUserId();
        if (userId) void getVault(userId).then(notifyVaultListeners);
        scanCurrentDrafts();
    },

    stop() {
        pluginStarted = false;
        DraftStore.removeChangeListener(onDraftStoreChanged);
        flushPendingCaptures();
        for (const userId of cleanupTimers.keys()) clearCleanupTimer(userId);
        observedDrafts.clear();
        closeModal(MODAL_KEY);
    },

    flux: {
        CONNECTION_OPEN() {
            flushPendingCaptures();
            observedDrafts.clear();
            const userId = getCurrentUserId();
            if (userId) void getVault(userId).then(() => {
                notifyVaultListeners();
                scanCurrentDrafts();
            });
        },
    },

    onBeforeMessageSend(channelId, message) {
        const userId = getCurrentUserId();
        if (!userId || typeof message?.content !== "string") return;
        void captureSnapshot(userId, channelId, message.content, "Before sending");
    },
});
