# DraftVault

> **BETA ONLY — Experimental software. Use at your own risk and keep backups of important drafts.**

**Local, automatic draft history for Discord.** DraftVault quietly keeps previous text versions of your unsent messages so you can recover something you accidentally deleted, replaced, or cleared.

Designed as one codebase for **Vencord and Equicord**.

## Features

- Automatically captures text versions when Discord's native `DraftStore` updates, with a short debounce to avoid saving every keystroke.
- Captures the outgoing text immediately before a message is sent, so a fast send is not missed by the debounce.
- Keeps a separate history per channel, DM, group DM, and thread.
- Restores a selected version through Discord's native draft manager. It navigates to the conversation and puts the text back into the composer; it never sends the message.
- If a different unsent draft is already present, DraftVault saves that current text as a version before restoring the selected one.
- Search across channel names, server names, and saved text.
- Compare any two saved versions with inline added/removed text highlighting.
- Protect (pin) important conversations so they are excluded from automatic inactivity cleanup and storage-limit trimming.
- Export all local history and protected-conversation settings to a JSON backup, then merge a backup into the current library without overwriting existing versions.
- Monitor DraftVault's estimated encoded storage size and optionally set a storage cap. When the cap is exceeded, the oldest unpinned revisions are removed first; the newest version in each conversation is kept.
- Delete individual versions or clear the history for a conversation.
- Stores text in DraftVault's own local IndexedDB store through the client's DataStore API; no external server, API key, telemetry, or network request is used by DraftVault.
- Keeps an unlimited number of versions per conversation (no fixed version or conversation-count cap; actual storage is still subject to the device/browser IndexedDB quota).
- Stores revisions as compact text deltas when that is smaller than a full copy, with periodic full checkpoints to keep recovery reliable. Each conversation has its own storage record, so saving a new version does not rewrite every other conversation. The new store is isolated from the clients’ shared plugin DataStore namespace.
- Automatically removes a conversation’s entire history after it has received no new saved version for the configured inactivity period. The default is `1mo`.

## Important behavior and limitations

- DraftVault stores **text only**. It does not copy, restore, or manage attachments, uploads, stickers, or other composer state. A single saved draft is limited to 10,000 characters.
- Autosaves are triggered by Discord's native DraftStore updates and then debounced by 550 ms. The before-send hook adds a final capture immediately before sending. If Discord itself has not emitted a draft-store update for very recent typing, that uncommitted text may not yet be in history.
- Automatic inactivity cleanup runs while DraftVault is enabled. If Discord is closed or the plugin is disabled when a history expires, that history is cleaned on the next plugin start.
- A protected conversation is excluded from both inactivity cleanup and automatic storage-cap trimming. Clearing its history also removes its protected status.
- The optional storage cap is a best-effort limit for DraftVault's estimated encoded history, not a guarantee about total Discord/IndexedDB usage. Protected histories and the newest version in every conversation are preserved, so the estimate can remain above the cap when there is nothing eligible to remove.
- JSON backups contain your draft text and channel IDs in readable form. Store them securely. Import merges versions by ID, skips matching IDs, and applies the current retention and storage-limit policies.
- Drafts are sensitive. They remain on the local device and are separated by Discord user ID. They are not encrypted independently by DraftVault; protect your local Discord/Vencord data directory accordingly.
- Restoring replaces the current composer draft for that conversation. DraftVault first snapshots a different non-empty current draft so it remains recoverable.
- No message is sent automatically.

## Installation

### Vencord (from source)

1. Clone/build Vencord from source. If you already built it from source, skip to step 2.

   ```bash
   git clone https://github.com/Vendicated/Vencord.git
   cd Vencord
   pnpm install --frozen-lockfile
   pnpm build
   pnpm inject
   ```

2. Copy the **entire `DraftVault` folder** into:

   ```text
   src/userplugins/DraftVault/
   ```

3. Build and inject Vencord again.
4. Enable **DraftVault** in Vencord's Plugins settings.

### Equicord (from source)

1. Clone/build Equicord from source. If you already built it from source, skip to step 2.

   ```bash
   git clone https://github.com/Equicord/Equicord.git
   cd Equicord
   pnpm install --frozen-lockfile
   pnpm build
   pnpm inject
   ```

2. Copy the **entire `DraftVault` folder** into:

   ```text
   src/userplugins/DraftVault/
   ```

3. Build and inject Equicord again.
4. Enable **DraftVault** in Equicord's Plugins settings.

### Source-build video

The following video demonstrates building a client from source. Use the Vencord or Equicord commands above as appropriate:

https://www.youtube.com/watch?v=XmVNRKrphlw

## Retention settings

In the DraftVault plugin settings, set **Retention period** by entering a positive number followed by one of these units:

| Unit | Meaning | Example |
| --- | --- | --- |
| `s` | Seconds | `30s` |
| `m` | Minutes | `10m` |
| `h` | Hours | `12h` |
| `mo` | Months (30 days) | `1mo` |
| `y` | Years (365 days) | `1y` |

The default is `1mo`. Months are treated as 30 days and years as 365 days. The period is an inactivity window for each conversation: every saved version in that conversation is retained while new versions continue to be captured. When no new version is saved for the configured period, DraftVault removes **the entire history for that unprotected conversation**. It does not age out older versions individually while the conversation remains active.

Changing the setting to a shorter period immediately removes histories that have already exceeded the new inactivity window. Existing 0.1.0 data is migrated automatically; versions that the old 25-version / 60-conversation limits had already deleted cannot be recovered. This is unlimited in the sense that DraftVault has no hard-coded version cap; it cannot bypass the storage quota imposed by the browser or operating system. A conversation that remains active for a very long time can still accumulate storage.

## Storage limit

The optional **Maximum storage (MB)** setting is blank by default, which means no custom limit. Enter a positive number such as `100` or `250.5` to enable a cap. If the estimate exceeds the cap, DraftVault removes the oldest eligible versions first, across unprotected conversations. It always keeps the newest version in each conversation and preserves all versions in protected conversations. If those protected/latest versions alone exceed the configured cap, DraftVault displays a warning instead of deleting them.

The Storage card in the DraftVault window reports the estimated size of its encoded local history. It does not measure all data stored by Discord or the full IndexedDB quota usage, and browser storage overhead can make actual disk usage differ.

## Usage

- Open DraftVault using the small vault icon in the chat toolbar, or use **Open DraftVault** from the client toolbox.
- Select a conversation in the left column.
- Select a saved version in the history list. The timeline shows 50 versions initially. Scroll down inside the version list to load older batches automatically; the **Load older versions** button remains available as a manual fallback.
- Use **Compare with** in the preview to compare the selected version with another version. Added text is highlighted in green and removed text in red.
- Use **Protect** on a conversation to keep its history out of inactivity cleanup and storage-limit trimming. Select **Protected** to remove that protection.
- Choose **Restore this draft**. DraftVault returns to that channel and restores the text to Discord's composer.
- Use the trash icon beside a version to delete just that version, or **Clear history** to remove all saved versions for the selected conversation.
- Use **Export backup** to download a JSON copy of all histories and protected conversations. Use **Import backup** to merge a previously exported file; it does not overwrite current history. Single-file backup export/import is limited to 50 MB and 250,000 versions per file.

## Privacy and safety

DraftVault reads the current user's native text drafts and the outgoing message text for the purpose of preserving draft versions. It writes only the resulting text history to DraftVault's dedicated local IndexedDB DataStore. It does not read Discord credentials or tokens, make HTTP requests, connect to third-party services, or send draft contents anywhere.

## Compatibility and testing

The plugin uses shared Vencord/Equicord APIs: `DraftStore`, `DraftType`, `DraftManager` (`saveDraft`), `ChannelRouter`, `Modal`, `ChatBarButton`, and the client `DataStore` API. The code is intended for both projects from one folder.

The TSX source is intended for both Vencord and Equicord, but a full source build and live in-client test have not been performed in this environment. The retention parser, delta round-trip, checkpoint interval, inactivity cleanup, storage trimming, backup validation/merge, comparison diff generation, and TSX transpilation were tested separately. Verify settings validation, import/export in the client, long-history loading, automatic cleanup, migration, and restore behavior on both clients before treating this as production-tested.
